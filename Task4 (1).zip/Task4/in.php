
<html>
<head>
<title>Task 4</title>
<link rel="stylesheet" href="style.css"/>

</head>
<body>

<div class="main">
	<div class="head">
		<img src="logo.png" width="80px" height="80px">
	</div><br>
<div class="menu">
	        <li><a href="msgs.php">Send Messages</a></li>
			<li><a href="in.php">Inbox</a></li>
			<li><a href="out.php">Outbox</a></li>
			<li><a href="logout.php">Signout</a></li>			
	</div><br>
		<div class="form">
<?php
   $servername = "localhost"; 
	$username = "root"; 
	$password = ""; 
	$database = "assgmt"; 
	$con = new mysqli($servername,$username,$password,$database);
	if($con->connect_errno){
	die("Connection failed: ". $con->connect_errorno);}
?>
<?php
	
		session_start(); 
	$user_email1 = $_SESSION['user_email'] ;

    $sql = "SELECT *FROM mess WHERE receiver_email = '$user_email1'";
	$result = mysqli_query($con , $sql);
?><br>
	<table width="340" height="250" >
	  <tr class ="top">		
		<th colspan = "2" >Inbox Messages</th></tr>
	<tr>
			<td><b>Emails</td>
			<td><b>Messages </td></tr>	       
        <?php
		 while($rows = mysqli_fetch_array($result))
		 {
		 ?> <tr>
		 <td> <?php echo $rows[1]; ?> </td>
		 <td> <?php echo $rows[2]; ?> </td>
		 </tr><?php } ?>
   </table>
   </div>

<div class="foot_two">Yahya Iqbal</div>
	
</div>
</body>
</html>