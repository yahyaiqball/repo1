
<html>
<head>
<title>Task 4</title>
<link rel="stylesheet" href="style.css"/>

</head>
<body>

<div class="main">
	<div class="head">
		<img src="logo.png" width="80px" height="80px">
	</div>
	<center>
	 <form method="POST" action="login.php">
	<table width="380" height="130">
    
	  <tr class ="top">		
		<th colspan = "2" >User Login</th>
		</tr>
		<tr>
			<td>Email:</td>
			<td> <input type = "text" name = "useremail" /></td>
		</tr>	
        <tr>
			<td> Password:</td>
			<td> <input type = "password" name = "userpassword" ></td><br> 
		</tr>	
		<tr class="button">
			<td colspan = "2"> <input type = "submit" name = "submit1" value="Login" /></td>
		</tr>			 
				 
      </form>
   </table>
  

	 <form method="POST" action="login.php" enctype="multipart/form-data">
	<table  width="380" height="200" > 
    
	  <tr class= "top">		
		<th colspan = "2">User registration</th></tr>
		<tr>
			<td> Name:</td>
			<td> <input type = "text" name = "name" /></td>
		</tr>	
		 <tr>
			<td>Email:</td>
			<td> <input type = "text" name = "email" ></td><br>
		</tr>
        <tr>
			<td>Password:</td>
			<td> <input type = "password" name = "password"></td><br>
		</tr>
		 <tr>
			<td>Your Picture:</td>
			<td> <input type = "file" name = "pic"></td><br>
		</tr>
		<tr class="button">
			<td colspan = "2"> <input type = "submit" name = "submit" value = "Register" /></td>
		</tr>			 
	</form>
   </table>
   </center>				 


<?php
   $servername = "localhost"; 
	$username = "root"; 
	$password = ""; 
	$database = "assgmt"; 
	$con = new mysqli($servername,$username,$password,$database);
	if($con->connect_errno){
	die("Connection failed: ". $con->connect_errorno);}
?>			

   <?php
		if(isset($_POST['submit1']))
		{
			$Uemail = $_POST['useremail'];
			$Upas = $_POST['userpassword'];
			$sql = "SELECT * FROM login WHERE user_email='$Uemail' && user_password='$Upas'";
			$result = mysqli_query($con , $sql);
			$rows = mysqli_num_rows($result);
			$result1 = mysqli_fetch_assoc($result);
			if($rows == 1)
			{
				session_start();
				$_SESSION['user_email'] = $Uemail;
				echo "<script>window.location.replace('info.php');</script>";
				
			}
		}	
?>
	
<?php	
if(isset($_POST['submit']))
{
	$name = $_POST['name'];
	$email =  $_POST['email'];
	$password =  $_POST['password'];
	$filename = $_FILES['pic']['name'];
	$tmpname = $_FILES['pic']['tmp_name'];

	$sql1 = "SELECT * FROM login WHERE user_email='$email'";
	$result1 = mysqli_query($con , $sql1);
	$rows = mysqli_num_rows($result1);	
			if($rows == 0 )
			{
				session_start();
				$_SESSION['user_email'] = $email;

				$destination = "folder/". $filename;
				move_uploaded_file($tmpname, $destination);

					$sql = "INSERT INTO `login` ( `user_name` ,`user_email`  , `user_password`  ,  `user_pic`) VALUES ( '$name', '$email', '$password', '$destination')";
					$result = mysqli_query($con , $sql);
					if($result)
					{
						echo "<script>window.location.replace('info.php');</script>";
					}
			}
			else
			{
				$email = null;
			}	
}		 
?>
	<div class="foot">Yahya Iqbal</div>
	
</div>
</body>
</html>