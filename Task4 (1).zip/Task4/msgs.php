
<html>
<head>
<title>Task 4</title>
<link rel="stylesheet" href="style.css"/>

</head>
<body>

<div class="main">
	<div class="head">
		<img src="logo.png" width="80px" height="80px">
	</div><br>
	<div class="menu">
	        <li><a href="msgs.php">Send Messages</a></li>
			<li><a href="in.php">Inbox</a></li>
			<li><a href="out.php">Outbox</a></li>
			<li><a href="logout.php">Signout</a></li>			
	</div><br>
	
	<div class="form">
	 <form method="POST" action="msgs.php">
	<table width="380" height="180">
    
	  <tr class ="top">		
		<th colspan = "2" >Send messages</th>
		</tr>
		<tr><td>Receiver Email</td>
			<td> <input type = "text" name = "user_email" /></td>
		</tr>	
        <tr><td> Message</td>
			<td> <textarea type = "text" name = "user_messages" rows="8" cols="20" ></textarea></td> 
		</tr>	
		<tr class="button">
			<td colspan = "2"> <input type = "submit" name = "submit" value="Send Message" /></td>
		</tr>			 			 
      </form>
   </table>
   </div>


<?php
   $servername = "localhost"; 
	$username = "root"; 
	$password = ""; 
	$database = "assgmt"; 
	$con = new mysqli($servername,$username,$password,$database);
	if($con->connect_errno){
	die("Connection failed: ". $con->connect_errorno);}
?>	
<?php
	session_start(); 
	$user_email1 = $_SESSION['user_email'] ;

if(isset($_POST['submit']))
{
	$user_email =  $_POST['user_email'];
	$user_messages =  $_POST['user_messages'];

		$sql = "INSERT INTO `mess` (`receiver_email` ,`user_email`, `message`) VALUES ( '$user_email','$user_email1', '$user_messages')";
		$result = mysqli_query($con , $sql);
}		 
?>
<div class="foot_two">Yahya Iqbal</div>
	
</div>
</body>
</html>