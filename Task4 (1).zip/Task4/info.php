
<html>
<head>
<title>Task 4</title>
<link rel="stylesheet" href="style.css"/>

</head>
<body>

<div class="main">
	<div class="head">
		<img src="logo.png" width="80px" height="80px">
	</div><br>
<div class="menu">
	        <li><a href="msgs.php">Send Messages</a></li>
			<li><a href="in.php">Inbox</a></li>
			<li><a href="out.php">Outbox</a></li>
			<li><a href="logout.php">Signout</a></li>			
	</div><br>
		<div class="form">
<?php
   $servername = "localhost"; 
	$username = "root"; 
	$password = ""; 
	$database = "assgmt"; 
	$con = new mysqli($servername,$username,$password,$database);
	if($con->connect_errno){
	die("Connection failed: ". $con->connect_errorno);}
?>
<?php
	session_start(); 
	$user_email1 = $_SESSION['user_email'] ;

    $sql = "SELECT *FROM login WHERE user_email = '$user_email1'";
	$result = mysqli_query($con , $sql);
?><br>
	<table width="440" height="250" >
	  <tr class ="top">		
		<th colspan = "3" >Information</th></tr>
	<tr>
		<td><b>Name</td>
			<td><b>Emails</td>
			<td><b>Image</td></tr>	       
        <?php
		 while($rows = mysqli_fetch_array($result))
		 {
		 ?> <tr>
		 <td> <?php echo $rows[0]; ?> </td>
		 <td> <?php echo $rows[1]; ?> </td>
		 <td><img src=" <?php echo $rows[3]; ?>" height="90" width="90"></td>
		 </tr><?php } ?>
   </table>
   </div>

<div class="foot_two">Yahya Iqbal</div>
	
</div>
</body>
</html>